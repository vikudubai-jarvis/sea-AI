import html
import traceback

import streamlit as st
import extra_streamlit_components as stx
from datetime import datetime, timedelta
from auth import (
    register_user, get_account, login_with_pin, login_with_name_age,
    change_name, change_age, change_pin,
)
from ai_tutor import is_ai_available, tutor_reply, get_hint_ai, prepare_image, REFUSAL_REPLY
from database import (
    init_db, create_remember_token, get_email_for_token, delete_remember_tokens_for_email, REMEMBER_DAYS
)
from guest_mode import (
    is_guest_trial_active, get_guest_info, create_guest_session,
    record_guest_usage, reset_guest_session, check_trial_expired
)
from sessions import (
    init_sessions_table, create_new_session, add_message_to_session,
    end_session, get_user_sessions, get_session_details, get_session_stats, delete_session
)

# Initialize database
init_db()
init_sessions_table()

# Page configuration
st.set_page_config(
    page_title="Sea - Student Education AI",
    page_icon="🌊",
    layout="centered",
    initial_sidebar_state="collapsed"
)

# Custom CSS for styling
st.markdown("""
    <style>
    .main {
        max-width: 800px;
    }
    .sea-header {
        text-align: center;
        color: #0066cc;
        margin-bottom: 30px;
    }
    .welcome-box {
        background-color: #e6f2ff;
        padding: 20px;
        border-radius: 10px;
        margin: 20px 0;
    }
    </style>
""", unsafe_allow_html=True)

# Initialize session state
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.user_data = None
    st.session_state.show_settings = False
    st.session_state.is_guest = False
    st.session_state.current_session_id = None
    st.session_state.view_page = "learn"  # "learn" or "sessions"

PER_USER_KEYS = (
    "learning_active", "opening_question", "current_question", "learning_stage", "student_answer", "conversation",
    "step_count", "closing_stage", "account_msg", "show_name_login",
    "settings_name", "settings_age", "settings_pin", "login_pin", "login_name", "login_age",
    "reg_name", "reg_age", "reg_pin",
)


def reset_user_state():
    """Forget everything from the previous person so the next login starts clean."""
    for key in PER_USER_KEYS:
        st.session_state.pop(key, None)
    st.session_state.current_session_id = None
    st.session_state.view_page = "learn"
    st.session_state.show_settings = False


FRIENDLY_ERROR = "Oops, Sea had trouble thinking just now. Please try again in a minute, or ask a grown-up for help."


def report_error():
    """Show kids a friendly message; the details go to the terminal for grown-ups."""
    traceback.print_exc()
    st.error(FRIENDLY_ERROR)


def show_text(text):
    st.markdown(text.replace("$", r"\$"))  # "$5 and $2" would otherwise render as maths


def save_to_history(msg, user_email, is_guest):
    if st.session_state.get("current_session_id") and not is_guest:
        add_message_to_session(st.session_state.current_session_id, user_email, msg["type"], msg["content"])


def add_reply(student_msg, reply_text, user_email, is_guest):
    sea_msg = {"type": "sea", "content": reply_text}
    if reply_text == REFUSAL_REPLY:
        student_msg["skip_api"] = sea_msg["skip_api"] = True
    st.session_state.conversation.append(sea_msg)
    save_to_history(student_msg, user_email, is_guest)
    save_to_history(sea_msg, user_email, is_guest)
    st.session_state.step_count += 1


def drop_last(msg):
    conversation = st.session_state.conversation
    if conversation and conversation[-1] is msg:
        conversation.pop()


REMEMBER_COOKIE = "sea_remember"
cookie_manager = stx.CookieManager(key="cookie_manager")

# Set on the run after login: setting it right before st.rerun() can be dropped by the browser component
if st.session_state.get("pending_remember_token"):
    cookie_manager.set(
        REMEMBER_COOKIE, st.session_state.pop("pending_remember_token"),
        expires_at=datetime.now() + timedelta(days=REMEMBER_DAYS),
        key="set_remember",
    )

if not st.session_state.logged_in:
    remembered_token = cookie_manager.get(cookie=REMEMBER_COOKIE)
    remembered_email = get_email_for_token(remembered_token) if remembered_token else None
    remembered_user = get_account(remembered_email) if remembered_email else None
    if remembered_user:
        st.session_state.logged_in = True
        st.session_state.user_data = remembered_user
        st.session_state.is_guest = False
        st.rerun()

# Main app logic
if not st.session_state.logged_in:
    st.markdown("<h1 class='sea-header'>🌊 Sea</h1>", unsafe_allow_html=True)
    st.write("Hey there! 👋 I'm **Sea**, your learning buddy. I'm here to help you learn about anything you want to know. Ask me anything - we'll figure it out together!")

    def finish_login(user_data, stay):
        reset_user_state()
        if stay:
            st.session_state.pending_remember_token = create_remember_token(user_data["email"])
        st.session_state.logged_in = True
        st.session_state.user_data = user_data
        st.session_state.is_guest = False
        st.rerun()

    tab1, tab2, tab3 = st.tabs(["Re-login", "Register", "Try Free (1 Month)"])

    with tab1:
        st.subheader("Re-login")
        stay_logged_in = st.checkbox(
            f"Stay logged in for {REMEMBER_DAYS} days (only on your own computer)",
            value=False, key="stay_logged_in",
        )

        with st.form("pin_login_form"):
            pin = st.text_input("Type your PIN", type="password", max_chars=4, key="login_pin")
            if st.form_submit_button("Login with PIN", key="pin_login_btn", type="primary"):
                user_data = login_with_pin(pin.strip())
                if user_data:
                    finish_login(user_data, stay_logged_in)
                else:
                    st.error("That PIN didn't match an account. Check it, or use your name and age.")

        with st.container(border=True):
            if st.button("Use age and name to login", key="show_name_login_btn"):
                st.session_state.show_name_login = not st.session_state.get("show_name_login", False)

            if st.session_state.get("show_name_login", False):
                with st.form("name_login_form", border=False):
                    login_name = st.text_input("Your Name", key="login_name")
                    login_age = st.number_input("Your Age", min_value=3, max_value=99, value=13, step=1, key="login_age")
                    if st.form_submit_button("Login", key="name_login_btn"):
                        user_data, error = login_with_name_age(login_name, int(login_age))
                        if user_data:
                            finish_login(user_data, stay_logged_in)
                        else:
                            st.error(error)

    with tab2:
        st.subheader("Create New Account")
        name = st.text_input("Your Name", key="reg_name")
        age = st.slider("Your Age", min_value=3, max_value=99, value=13, key="reg_age")
        reg_pin = st.text_input("Make a 4-number PIN (you'll use it to log in)", type="password", max_chars=4, key="reg_pin")

        if st.button("Register", key="register_btn"):
            if name and reg_pin:
                success, message, account_id = register_user(name, age, reg_pin.strip())
                if success:
                    finish_login(get_account(account_id), stay=False)
                else:
                    st.error(message)
            else:
                st.error("Please fill in your name and a PIN.")

    with tab3:
        st.subheader("🎉 Free Trial - 1 Month")

        # Check if trial is expired
        if check_trial_expired():
            st.error("❌ Your 1-month free trial has ended!")
            st.warning("Please **Login** or **Register** to continue using Sea.")
            st.info("💾 All your questions and chats are saved! Just log in with your PIN.")
        else:
            guest_info = get_guest_info()

            if not guest_info['locked_out']:
                st.success(f"✅ Free trial active! You have **{guest_info['days_left']} days** left")
                st.write(f"📊 Questions asked so far: **{guest_info['usage_count']}**")
                st.info("💾 All your learning will be saved! After 1 month, just login to continue.")

                guest_age = st.slider("How old are you?", min_value=3, max_value=99, value=8, key="guest_age")
                if st.button("Start Free Trial", key="guest_btn", type="primary"):
                    reset_user_state()
                    st.session_state.logged_in = True
                    st.session_state.is_guest = True
                    st.session_state.user_data = {
                        "name": "Guest User",
                        "age": guest_age,
                        "email": "guest@sea.local",
                        "is_guest": True
                    }
                    st.rerun()
            else:
                st.error("❌ Your trial has expired!")
                st.warning("Please login or register to continue.")

else:
    # Main app after login
    user_name = st.session_state.user_data['name']
    user_age = st.session_state.user_data['age']
    user_email = st.session_state.user_data['email']
    is_guest = st.session_state.is_guest

    # Check if guest trial expired
    if is_guest and check_trial_expired():
        st.error("⏰ Your 1-month free trial has ended!")
        st.warning("Please **Re-login** or **Register** to continue.")
        st.info("💾 All your questions are saved! When you login, you can see everything.")

        if st.button("Login Now"):
            reset_user_state()
            st.session_state.logged_in = False
            st.session_state.user_data = None
            st.session_state.is_guest = False
            st.rerun()
        st.stop()

    st.markdown(f"<h1 class='sea-header'>🌊 Hey {html.escape(user_name)}! Sea here!</h1>", unsafe_allow_html=True)
    st.write("Ready to learn something awesome? Ask me ANYTHING! 💪")

    if is_guest:
        guest_info = get_guest_info()
        st.write(f"⏳ **Free Trial:** {guest_info['days_left']} days left | Questions: {guest_info['usage_count']}")
        st.info("After 1 month, you'll need to login to continue. All your chats are saved! 💾")
    else:
        st.write(f"**You:** {user_age} years old | **Me:** Sea, ready to teach!")

    # Top menu with navigation
    col1, col2, col3, col4, col5, col6 = st.columns(6)
    with col1:
        if st.button("📚 Learn", use_container_width=True):
            st.session_state.view_page = "learn"
            st.rerun()
    with col2:
        if st.button("📋 Sessions", use_container_width=True):
            st.session_state.view_page = "sessions"
            st.rerun()
    with col4:
        if st.button("⚙️ Settings", use_container_width=True):
            st.session_state.show_settings = not st.session_state.get("show_settings", False)
            st.rerun()
    with col6:
        if st.button("Logout", use_container_width=True):
            # End current session if in learn mode
            if st.session_state.view_page == "learn" and st.session_state.learning_active:
                if st.session_state.current_session_id and not is_guest:
                    end_session(st.session_state.current_session_id, user_email)
            delete_remember_tokens_for_email(user_email)
            if cookie_manager.get(cookie=REMEMBER_COOKIE):
                cookie_manager.delete(REMEMBER_COOKIE, key="delete_remember")
            reset_user_state()
            st.session_state.logged_in = False
            st.session_state.user_data = None
            st.session_state.is_guest = False
            st.rerun()

    # Settings panel
    if st.session_state.get("show_settings", False):
        st.divider()
        st.subheader("⚙️ Settings & Backup")

        if not is_guest:
            with st.expander("👤 My Account", expanded=True):
                def apply_account_change(ok, msg, **updates):
                    if ok:
                        st.session_state.user_data.update(updates)
                        st.session_state.account_msg = msg
                        st.rerun()
                    else:
                        st.error(msg)

                account_msg = st.session_state.pop("account_msg", None)
                if account_msg:
                    st.success(account_msg)

                new_name = st.text_input("Name", value=user_name, key="settings_name")
                if st.button("Change name", key="change_name_btn"):
                    ok, msg = change_name(user_email, new_name)
                    apply_account_change(ok, msg, name=new_name.strip())

                new_age = st.slider("Age", min_value=3, max_value=99, value=int(user_age), key="settings_age")
                if st.button("Change age", key="change_age_btn"):
                    ok, msg = change_age(user_email, int(new_age))
                    apply_account_change(ok, msg, age=int(new_age))

                new_pin = st.text_input("New 4-number PIN", type="password", max_chars=4, key="settings_pin")
                if st.button("Change PIN", key="change_pin_btn"):
                    ok, msg = change_pin(user_email, new_pin.strip())
                    apply_account_change(ok, msg)

        with st.expander("📦 Data Backup & Recovery", expanded=True):
            st.write("**Automatic backups** are created every time the app starts.")

            col1, col2 = st.columns(2)

            with col1:
                if st.button("💾 Create Manual Backup"):
                    from backup import backup_database
                    success, message = backup_database()
                    if success:
                        st.success(message)
                    else:
                        st.error(message)

            with col2:
                if st.button("📂 View Backups"):
                    from backup import list_backups
                    backups = list_backups()
                    if backups:
                        st.write("Available backups:")
                        for backup in backups:
                            size_kb = backup['size'] / 1024
                            st.caption(f"📁 {backup['name']} ({size_kb:.1f} KB)")
                    else:
                        st.info("No backups yet")

            st.info("💡 **Tip:** If the app resets and you can't login with your old account, you can restore from a backup here!")

        st.divider()

    st.divider()

    # SESSIONS PAGE VIEW
    if st.session_state.view_page == "sessions" and not is_guest:
        st.subheader("📋 Your Learning Sessions")

        # Get stats
        stats = get_session_stats(user_email)

        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Sessions", stats["total_sessions"])
        with col2:
            st.metric("Questions Asked", stats["total_questions"])
        with col3:
            if stats["last_session"]:
                st.metric("Last Session", stats["last_session"][:10])

        st.divider()

        # Get all sessions
        sessions = get_user_sessions(user_email, limit=50)

        if sessions:
            st.write(f"**Your {len(sessions)} Recent Sessions:**")

            for session in sessions:
                session_id, question, started_at, ended_at, status, questions_count = session

                with st.expander(f"📌 {question[:50]}... ({status}) - {started_at[:10]}", expanded=False):
                    st.write(f"**Session ID:** {session_id}")
                    st.write(f"**Started:** {started_at}")
                    if ended_at:
                        st.write(f"**Ended:** {ended_at}")
                    st.write(f"**Questions Asked:** {questions_count}")
                    st.write(f"**Status:** {status}")

                    # Show session details
                    if st.button(f"View Full Session", key=f"view_{session_id}"):
                        session_info, messages = get_session_details(session_id, user_email)

                        st.write("---")
                        st.write("**Session Conversation:**")

                        for msg_type, content, timestamp in messages:
                            if msg_type == "student":
                                with st.chat_message("user"):
                                    st.write(content[:200] + "..." if len(content) > 200 else content)
                            else:
                                with st.chat_message("assistant", avatar="🌊"):
                                    st.write(content[:300] + "..." if len(content) > 300 else content)

                    # Delete option
                    if st.button(f"🗑️ Delete Session", key=f"delete_{session_id}"):
                        delete_session(session_id, user_email)
                        st.success("Session deleted!")
                        st.rerun()
        else:
            st.info("No learning sessions yet. Start learning to create your first session! 🌊")

        st.stop()  # Don't show learning interface when viewing sessions

    # Initialize session state for learning session
    if "learning_active" not in st.session_state:
        st.session_state.learning_active = False
        st.session_state.current_question = None
        st.session_state.learning_stage = "initial"
        st.session_state.student_answer = ""
        st.session_state.conversation = []
        st.session_state.step_count = 0

    # Main question answering interface
    if not st.session_state.learning_active:
        # Show "New Session" button to reset the form
        if st.button("➕ New Session", use_container_width=False):
            st.session_state.current_session_id = None
            st.rerun()

        st.subheader("💡 Ask Me Anything")
        st.write("Ask any question, and I'll help you learn by explaining concepts and asking guiding questions.")

        question = st.text_area("Your Question:", placeholder="e.g., How does photosynthesis work? What is algebra? How do magnets work?", height=100, key="user_question")

        col1, col2 = st.columns(2)
        with col1:
            if st.button("Start Learning", type="primary"):
                if question.strip():
                    # Create new session (unless guest)
                    if not is_guest:
                        session_id = create_new_session(user_email, question)
                        st.session_state.current_session_id = session_id

                    st.session_state.learning_active = True
                    st.session_state.opening_question = question
                    st.session_state.current_question = question
                    st.session_state.learning_stage = "intro"
                    st.session_state.closing_stage = None
                    st.session_state.conversation = []
                    st.session_state.step_count = 0
                    st.rerun()
                else:
                    st.warning("Please enter a question first!")

    else:
        # Interactive learning conversation with AI (or offline mode)
        st.subheader("📚 Learning Session")
        st.caption(f"Question: {st.session_state.current_question}")
        answers_given = sum(1 for m in st.session_state.conversation if m["type"] == "student")
        st.progress(min(answers_given / 5, 1.0), text=f"Session progress: {min(answers_given, 5)} of 5 answers")

        api_available = is_ai_available()
        opening_question = st.session_state.get("opening_question") or st.session_state.current_question

        if not api_available:
            st.info("💡 Running in **Offline Mode** (no API key needed!) - Uses built-in knowledge for common topics")

        # Get initial explanation if starting
        if st.session_state.learning_stage == "intro":
            with st.spinner("🌊 Sea is thinking..."):
                from teaching import start_learning_session

                intro_response = None
                if api_available:
                    try:
                        intro_response = tutor_reply(opening_question, [], user_name, user_age)
                    except Exception:
                        traceback.print_exc()  # fall back to offline guidance below instead of retrying on every rerun
                if intro_response is None:
                    intro_response = start_learning_session(st.session_state.current_question, user_age)

                if is_guest:
                    record_guest_usage()
                intro = {"type": "sea", "content": intro_response}
                st.session_state.conversation.append(intro)
                save_to_history(intro, user_email, is_guest)
                st.session_state.learning_stage = "answering"
                st.rerun()

        # Chat interface
        if st.session_state.learning_stage == "answering":
            # Chat options bar
            col1, col2 = st.columns([6, 1])

            with col2:
                if st.button("💡 Hint", use_container_width=True):
                    with st.spinner("Getting hint..."):
                        try:
                            if api_available:
                                hint = get_hint_ai(opening_question, st.session_state.conversation, user_name, user_age)
                            else:
                                from teaching import get_hint
                                hint = get_hint(st.session_state.current_question, user_age)
                        except Exception:
                            report_error()
                        else:
                            hint_msg = {"type": "hint", "content": hint}
                            st.session_state.conversation.append(hint_msg)
                            save_to_history(hint_msg, user_email, is_guest)
                            st.rerun()

            st.divider()

            # Chat messages
            chat_container = st.container(height=400)

            with chat_container:
                for msg in st.session_state.conversation:
                    if msg["type"] == "sea":
                        with st.chat_message("assistant", avatar="🌊"):
                            show_text(msg["content"])
                    elif msg["type"] == "student":
                        with st.chat_message("user"):
                            show_text(msg["content"])
                    elif msg["type"] == "hint":
                        with st.chat_message("assistant", avatar="💡"):
                            show_text(f"**Hint:** {msg['content']}")

            st.divider()

            # A new key after each picture empties the uploader, so the same photo isn't sent twice
            uploaded = st.file_uploader(
                "📷 Stuck on an exam or homework question? Upload a picture of it",
                type=["png", "jpg", "jpeg"],
                key=f"problem_pic_{st.session_state.get('pic_round', 0)}",
            )
            if api_available:
                st.caption("Messages and pictures are sent to Anthropic's Claude AI so Sea can help. "
                           "Please don't upload pictures that show faces, full names or addresses.")
            if uploaded and st.button("Help me with this picture", key="pic_help_btn"):
                if api_available:
                    try:
                        image_bytes, media_type = prepare_image(uploaded.getvalue())
                    except ValueError:
                        st.error("Sea couldn't open that picture. Try a clear PNG or JPG photo.")
                    else:
                        pic_msg = {
                            "type": "student",
                            "content": "📷 Here's a picture of a problem I'm stuck on. Can you help me work it out?",
                            "image": image_bytes,
                            "media_type": media_type,
                        }
                        st.session_state.conversation.append(pic_msg)
                        with st.spinner("🌊 Sea is looking at your picture..."):
                            try:
                                help_text = tutor_reply(opening_question, st.session_state.conversation, user_name, user_age)
                            except Exception:
                                drop_last(pic_msg)
                                report_error()
                            else:
                                add_reply(pic_msg, help_text, user_email, is_guest)
                                st.session_state.pic_round = st.session_state.get("pic_round", 0) + 1
                                st.rerun()
                else:
                    st.info("Picture help needs AI mode. Add your ANTHROPIC_API_KEY to use it.")

            # Chat input - bottom row
            col1, col2 = st.columns([6, 1])

            with col1:
                user_message = st.chat_input("Type your answer or ask a question...", key="chat_input")

            # Process message if entered
            if user_message:
                from teaching import (
                    start_learning_session, get_next_teaching_step, is_new_question, mentions_new_question,
                    closing_step, SURE_PROMPT, is_goodbye, GOODBYE_REPLY, is_dont_know, step_by_step_help,
                )

                closing = st.session_state.get("closing_stage")
                current = st.session_state.current_question
                last_sea = next((m["content"] for m in reversed(st.session_state.conversation) if m["type"] == "sea"), "")
                awaiting_explanation = "explain HOW" in last_sea

                student_msg = {"type": "student", "content": user_message}
                st.session_state.conversation.append(student_msg)

                with st.spinner("🌊 Sea is thinking..."):
                    try:
                        if api_available:
                            # Claude follows the whole tutoring flow itself (see ai_tutor.SYSTEM_TEMPLATE)
                            if is_new_question(user_message, current):
                                st.session_state.current_question = user_message
                            response = tutor_reply(opening_question, st.session_state.conversation, user_name, user_age)
                        elif is_goodbye(user_message):
                            response = GOODBYE_REPLY
                        elif is_dont_know(user_message) and not mentions_new_question(user_message, current):
                            response = step_by_step_help(current, user_age)
                        elif closing in ("sure", "learn_more"):
                            response, st.session_state.closing_stage = closing_step(closing, user_message)
                        elif closing == "need_help" or is_new_question(user_message, current, awaiting_explanation) \
                                or mentions_new_question(user_message, current):
                            st.session_state.closing_stage = None
                            st.session_state.current_question = user_message
                            response = start_learning_session(user_message, user_age)
                        else:
                            response = get_next_teaching_step(
                                current, user_message, user_age, st.session_state.step_count,
                                awaiting_explanation=awaiting_explanation,
                            )
                            if response == SURE_PROMPT:
                                st.session_state.closing_stage = "sure"
                    except Exception:
                        drop_last(student_msg)
                        report_error()
                    else:
                        add_reply(student_msg, response, user_email, is_guest)
                        st.rerun()

            with col2:
                if st.button("🏁 End", use_container_width=True, key="end_session_btn"):
                    # End session in database (if not guest)
                    if st.session_state.current_session_id and not is_guest:
                        end_session(st.session_state.current_session_id, user_email)

                    st.session_state.learning_active = False
                    st.session_state.learning_stage = "initial"
                    st.session_state.conversation = []
                    st.session_state.current_session_id = None
                    st.success("Great learning session! 🌊")
                    st.rerun()
