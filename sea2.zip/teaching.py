"""
SIMPLE TEACHING ENGINE - My baby AI Sea's brain! 🌊
No complexity, just ANSWERS then QUESTIONS
"""

import re
from difflib import SequenceMatcher

from teach_simple import (
    teach, is_math_question, try_simple_math, normalize_math, find_known_topic, topic_hints,
)

QUESTION_WORDS = {"what", "how", "why", "who", "when", "where", "explain", "tell", "can", "does", "do"}


def start_learning_session(question, age):
    """Start learning session - returns ANSWER then question"""
    return teach(question, age)


QUESTION_START = re.compile(
    r"^(?:(?:but|and|so|ok|okay|um+|hm+|wait)\b[\s,]*)?(" + "|".join(QUESTION_WORDS) + r"|is|are)\b"
)
# While Sea waits for "how did you solve it", answers often start with how/when/can/do
EXPLANATION_SAFE_STARTS = {"what", "why", "who", "where", "explain", "tell"}


def math_signature(text):
    m = re.search(r'(\d+)\s*([+\-*/%])\s*(\d+)', normalize_math(text))
    return m.groups() if m else None


def is_new_question(text, current_question="", awaiting_explanation=False):
    """True when the student is asking something new rather than answering."""
    t = text.strip().lower()
    if "=" in t:
        return False
    sig = math_signature(t)
    if sig and sig != math_signature(current_question):
        return True
    m = QUESTION_START.match(t)
    if not m:
        return False
    if m.group(1) in ("is", "are"):
        return False  # "is it 55" is an answer
    return not awaiting_explanation or m.group(1) in EXPLANATION_SAFE_STARTS


def mentions_new_question(text, current_question):
    """'I don't know what gravity is' names a different topic or sum than the one being worked on."""
    topic = find_known_topic(text)
    if topic and topic != find_known_topic(current_question):
        return True
    sig = math_signature(text)
    return bool(sig) and sig != math_signature(current_question)


OPERATION_WORD = re.compile(
    r'\b(add|adding|added|plus|subtract|subtracting|minus|take|taking|took|times|multiply|multiplied|'
    r'multiplying|divide|divided|dividing|share|sharing|sum|total|combine|combined)\b'
)
DONT_KNOW_PHRASES = (
    "i dont know", "dont know", "i do not know", "idk", "dunno", "idunno", "duno", "donno", "dono",
    "no idea", "no clue",
)
DONT_KNOW_TARGETS = ("i dont know", "dont know")
SQUASHED_TARGETS = ("idontknow", "dontknow", "idunno")


def _looks_like_dont_know(window, target):
    # "I do know" / "I did know" is spelled almost like "I don't know" but means the opposite
    if {"do", "did"} & set(window.split()) or "doknow" in window.replace(" ", ""):
        return False
    return SequenceMatcher(None, window, target).ratio() >= 0.8


def is_dont_know(text):
    """'I don't know', including typos like 'I don now', 'i do't know' or 'idontknow'."""
    t = " ".join(re.sub(r"[^a-z ]", "", text.lower()).split())
    if any(re.search(rf"\b{phrase}\b", t) for phrase in DONT_KNOW_PHRASES):
        return True
    words = t.split()
    if len(words) == 1:
        return any(_looks_like_dont_know(words[0], target) for target in SQUASHED_TARGETS)
    for target in DONT_KNOW_TARGETS:
        n = len(target.split())
        for size in (n - 1, n, n + 1):
            for i in range(max(len(words) - size + 1, 0)):
                if size and _looks_like_dont_know(" ".join(words[i:i + size]), target):
                    return True
    return False


def step_by_step_help(question, age=10):
    m = re.search(r'(\d+)\s*([+\-*/%])\s*(\d+)', normalize_math(question))
    if not m:
        topic = find_known_topic(question)
        hints = topic_hints(topic, age) if topic else []
        if hints:
            steps = "\n".join(f"Step {i}: {hint}" for i, hint in enumerate(hints, start=1))
            return f"""No problem! Let's figure out **{topic}** one step at a time:

{steps}

Start with Step 1 and tell me what you think!"""
        return f"""No problem! Let's break **{question}** into steps.

Step 1: Find the most important number or word in the question.
Step 2: Say in your own words what the question is asking.
Step 3: Tell me what you think Step 2 means."""

    a, op, b = m.group(1), m.group(2), m.group(3)

    if op == '+':
        steps = f"""Step 1: Start at **{a}**.
Step 2: Count up **{b}** more, one at a time.
Step 3: The number you land on is the answer."""
    elif op == '-':
        steps = f"""Step 1: Start with **{a}**.
Step 2: Count back **{b}**, one at a time (or cross out **{b}** of them).
Step 3: The number you stop on is the answer."""
    elif op == '*':
        steps = f"""Step 1: Write **{a}** down **{b}** times.
Step 2: Add all of them together."""
    elif op == '/':
        steps = f"""Step 1: Start with **{a}**.
Step 2: Split it into **{b}** equal groups, one at a time.
Step 3: Count how many are in one group."""
    else:
        steps = f"""Step 1: Start with **{a}**.
Step 2: Work with **{b}** using the operation in the question.
Step 3: Check your result."""

    return f"""No problem, let's do **{question}** step by step:

{steps}

Work through the steps and tell me what you get!"""


GOODBYE_PATTERN = re.compile(r'\b(bye|goodbye|good bye|see you|see ya|cya)\b')
GOODBYE_REPLY = "Bye! Have a great day, and come back anytime to keep learning!"


def is_goodbye(text):
    return GOODBYE_PATTERN.search(text.strip().lower()) is not None


SURE_PROMPT = "Okay, are you sure?"
YES_WORDS = {"yes", "y", "yeah", "yep", "yup", "sure", "ok", "okay"}
NO_WORDS = {"no", "n", "nope", "nah"}


def closing_step(stage, text):
    """Handle a yes/no reply after the student explains; returns (reply, next_stage)"""
    words = re.sub(r"[^a-z ]", "", text.lower()).split()
    first = words[0] if words else ""
    if first not in YES_WORDS | NO_WORDS:
        return "Please type **yes** or **no**.", stage

    is_yes = first in YES_WORDS
    if stage == "sure":
        if is_yes:
            return "Okay, do you want to learn more?", "learn_more"
        return "Okay, let's keep going. What are you unsure about?", None

    if is_yes:
        return "What do you need help with?", "need_help"
    return "Okay, enjoy your day!", None


def wrong_answer_hint(question, given):
    m = re.search(r'(\d+)\s*([+\-*/%])\s*(\d+)', normalize_math(question))
    if not m:
        return f"""You said **{given}**. Let's think about it step by step. What do you get now?"""

    a, op, b = m.group(1), m.group(2), m.group(3)

    if op == '-':
        story = f"""Imagine a person has **{a} chocolates**, and they take away **{b}** of them.
How many chocolates does that person have left?"""
    elif op == '+':
        story = f"""Imagine a person has **{a} chocolates**, and a friend gives them **{b}** more.
How many chocolates do they have now?"""
    elif op == '*':
        story = f"""Imagine **{a} bags**, and each bag has **{b} chocolates** in it.
How many chocolates are there in total?"""
    elif op == '/':
        story = f"""Imagine a person has **{a} chocolates** and shares them equally between **{b} friends**.
How many chocolates does each friend get?"""
    else:
        story = "Let's count it out step by step. What do you get now?"

    return f"""You said **{given}**. Let's check with a story:

{story}

Try it and tell me your new answer!"""


def get_next_teaching_step(question, student_answer, age, step_count, awaiting_explanation=False):
    """Give feedback on the student's answer and keep the conversation going"""
    question = question.strip()
    if is_math_question(question.lower()):
        expected = try_simple_math(question)
        cleaned = re.sub(r'\bstep\s*\d+\b', '', student_answer.lower())
        numbers = [int(n) for n in re.findall(r'-?\d+', cleaned)]
        explained = OPERATION_WORD.search(cleaned) is not None

        if expected is None:
            if not numbers:
                return f"""Good thinking! Try the steps above and tell me the number you get for **{question}**."""
            return f"""You said **{numbers[-1]}**. Walk me through how you got it - what did you do first?"""

        # Grade the last number only: "I had 4, took away 2 and got 3" mentions 2 but answers 3
        if (numbers and numbers[-1] == expected) or (awaiting_explanation and explained):
            if awaiting_explanation:
                return SURE_PROMPT
            return f"""Good job! **{question}** = **{expected}**. You got it!

Can you explain HOW you solved it?"""

        if explained:
            return f"""You're on the right track! Use that idea to finish the math: **{question}**. What do you get?"""

        if not numbers:
            return f"""Good thinking! Try the steps above and tell me the number you get for **{question}**."""

        return wrong_answer_hint(question, numbers[-1])

    topic = find_known_topic(question)
    hints = topic_hints(topic, age) if topic else []
    if hints:
        hint = hints[step_count % len(hints)]
        return f"""Good thinking! You said *"{student_answer}"*.

Here's something to think about next: {hint}

What do you think?"""

    return f"""Good thinking! You said *"{student_answer}"*.

What part of **{question}** feels most interesting to you? Tell me what you'd like to figure out next."""


def get_hint(question, age):
    """Give a hint without spoiling"""
    return f"Think about what you already know... What connections can you make with {question}?"
